from flask import Flask, request
import requests

app = Flask(__name__)

@app.route('/relay', methods=['POST'])
def relay():
    try:
        payload = request.get_json()
        url = payload['url']
        headers = payload.get('headers', {})
        data = payload.get('data', {})

        proxies = {
            'http': 'socks5h://127.0.0.1:9050',
            'https': 'socks5h://127.0.0.1:9050'
        }

        res = requests.post(url, headers=headers, json=data, proxies=proxies, timeout=15)
        return res.text, res.status_code

    except Exception as e:
        return str(e), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5001)
