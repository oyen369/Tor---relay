# Tor Relay Middleware

Skrip ini menjembatani aplikasi seperti MCP Tools agar bisa akses .onion lewat Tor proxy.

## Jalankan secara manual:
```
python tor_relay.py
```

## Jalankan via Docker:
```
docker build -t tor-relay .
docker run -d -p 5001:5001 --network="host" tor-relay
```

## Tes Endpoint:
POST ke: `http://127.0.0.1:5001/relay`

Body JSON:
```
{
  "url": "http://example.onion",
  "headers": {},
  "data": {}
}
```
